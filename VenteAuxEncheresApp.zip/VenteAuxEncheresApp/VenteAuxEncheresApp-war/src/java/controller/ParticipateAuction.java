/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Participe;
import entities.ParticipePK;
import entities.Utilisateur;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.ArticleFacadeLocal;
import model.ParticipeFacadeLocal;

/**
 *
 * @author Lenovo
 */
public class ParticipateAuction extends HttpServlet {

    @EJB
    private ArticleFacadeLocal articleFacade;

    @EJB
    private ParticipeFacadeLocal participeFacade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        
            HttpSession session = request.getSession(true);
            Utilisateur user = (Utilisateur) session.getAttribute("user");
        
        String idArt_tmp = request.getParameter("articleID");
        String newAuction = request.getParameter("newAuction");
        String action = request.getParameter("action");

        ParticipePK pk = new ParticipePK(Long.parseLong(idArt_tmp), user.getIdUser());

        Participe participe = new Participe(pk);
        
        if (action != null && "Valider".equalsIgnoreCase(action)) {
            if (newAuction != null && new Double(newAuction) >= (participeFacade.getMaxPrix(new Long(idArt_tmp)) + 0.01)) {
                participe.setPrixemis(new Double(newAuction));
                participe.setDateparticipation(new Date());
                participeFacade.merge(participe);
            }
        }

        request.setAttribute("idArt", idArt_tmp);
        //request.setAttribute("idUsr", user.getIdUser());
        
        if(participeFacade.getMaxPrix(new Long(idArt_tmp)) - Math.floor(participeFacade.getMaxPrix(new Long(idArt_tmp))) == 0.) {
            request.setAttribute("enchereMax", (int) participeFacade.getMaxPrix(new Long(idArt_tmp)));
        } else {
            request.setAttribute("enchereMax", participeFacade.getMaxPrix(new Long(idArt_tmp)));
        }
        request.getRequestDispatcher("ParticipateAuction.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
