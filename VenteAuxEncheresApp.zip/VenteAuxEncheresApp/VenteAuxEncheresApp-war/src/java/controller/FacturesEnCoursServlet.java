/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Commande;
import entities.Facture;
import entities.Utilisateur;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.CommandeFacadeLocal;
import model.FactureFacadeLocal;

/**
 *
 * @author Lenovo
 */
public class FacturesEnCoursServlet extends HttpServlet {

    @EJB
    private FactureFacadeLocal factureFacade;

    @EJB
    private CommandeFacadeLocal commandeFacade;
   
    
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
        HttpSession session = request.getSession(true);
        Utilisateur user = (Utilisateur) session.getAttribute("user");
       
         List<Commande> commandesWait = commandeFacade.getCmdToFacturateUSer(user.getIdUser());
         
         List<Facture> factures = factureFacade.getFactureByUser(user.getIdUser());
         request.setAttribute("factures", factures);
         
         if(request.getParameter("commandeID") != null){
             Commande cmd = commandeFacade.recupererCMD(Long.parseLong(request.getParameter("commandeID")));
             request.setAttribute("cmd", cmd);
             request.setAttribute("typeBill", 0);
             request.setAttribute("type", 1); 
             request.setAttribute("commandes", commandesWait); 
             request.getRequestDispatcher("ListBillsUser.jsp").forward(request, response);
         }else{
             
           if(request.getParameter("factureIndex") != null){
               request.setAttribute("typeBill", 1);
               request.setAttribute("type",0); 
               
                Facture facture = factures.get(Integer.parseInt(request.getParameter("factureIndex")));
                request.setAttribute("facture", facture);
                 request.setAttribute("commandes", commandesWait); 
             request.getRequestDispatcher("ListBillsUser.jsp").forward(request, response);
           }else{
                request.setAttribute("typeBill", 0);
                request.setAttribute("type", 0);    
                request.setAttribute("commandes", commandesWait); 
                request.getRequestDispatcher("ListBillsUser.jsp").forward(request, response); 
           }
            
         }
         
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
