/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Commande;
import entities.Utilisateur;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.CommandeFacadeLocal;

/**
 *
 * @author Lenovo
 */
public class FacturationReqServlet extends HttpServlet {

    @EJB
    private CommandeFacadeLocal commandeFacade;

    
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Long idCMD;
        String action = request.getParameter("action");
        HttpSession session = request.getSession(true);
        Utilisateur user = (Utilisateur) session.getAttribute("user");
               
        if ("Confirm".equalsIgnoreCase(action)) {
             if(request.getParameter("cb").length() != 16 ){
                 idCMD = Long.parseLong(request.getParameter("idCm"));
                 request.setAttribute("idCMD", idCMD);
                 request.setAttribute("error", "A valid Bank Card Number is required");
                 request.setAttribute("utilisateur", user);
                 request.getRequestDispatcher("FacturationConfirmation.jsp").forward(request, response);
             }else{
                 if(//on vérifie les autres champs
                    ((user.getNomUser().length() != 0) && (!user.getNomUser().equals(request.getParameter("nom"))))
                 || ((user.getPrenomUser().length() != 0) && (!user.getPrenomUser().equals(request.getParameter("prenom"))))
                 || ((user.getEmail().length() != 0) && (!user.getEmail().equals(request.getParameter("email"))))
                 || ((user.getPassword().length() != 0) && (!user.getPassword().equals(request.getParameter("password"))))
                 || ((user.getTel().length() != 0) && (!user.getTel().equals(request.getParameter("telephone"))))
                 || ((user.getPays().length() != 0) && (!user.getPays().equals(request.getParameter("pays"))))
                 || ((user.getVille().length() != 0) && (!user.getVille().equals(request.getParameter("ville"))) )
                 || ((user.getRue().length() != 0) && ( !user.getRue().equals(request.getParameter("rue")))   )      
                 || ((user.getCodePostal().toString().length() != 0) && (user.getCodePostal() != Integer.parseInt(request.getParameter("code"))))         
                         ){
                      idCMD = Long.parseLong(request.getParameter("idCm"));
                      request.setAttribute("idCMD", idCMD);
                      request.setAttribute("error", "One of the information entered is not valid! Please check your input entry");
                      
                      request.setAttribute("utilisateur", user);
                      request.getRequestDispatcher("FacturationConfirmation.jsp").forward(request, response);
                 }else{//on a validé la dmd
                     Commande cmd =  commandeFacade.recupererCMD(Long.parseLong(request.getParameter("idCm")));
                     cmd.setEtatDmd("Billing in progress");
                     cmd.setDateDmdFacturation(new Date());
                     commandeFacade.edit(cmd);
                     
                     response.sendRedirect("./FacturesEnCoursServlet");
                 }
             }
         }else{
             if("Cancel".equalsIgnoreCase(action)){
                 response.sendRedirect("./OdersListServlet");
             }else{
                 idCMD = (long) request.getAttribute("commandeID");
                 request.setAttribute("idCMD", idCMD);
                 request.setAttribute("utilisateur", user);
                 request.getRequestDispatcher("FacturationConfirmation.jsp").forward(request, response);
             }
         }
        
      
        
    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
