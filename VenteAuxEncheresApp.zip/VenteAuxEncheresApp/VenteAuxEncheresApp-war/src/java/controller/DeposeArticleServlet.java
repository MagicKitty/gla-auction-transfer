/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;


import entities.Article;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import entities.Categorie;
import entities.Utilisateur;
import java.io.File;
import javax.servlet.http.Part;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.ArticleFacadeLocal;
import model.CategorieFacadeLocal;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2 // 2M
        ,
         maxFileSize = 1024 * 1024 * 10 // 10M
        ,
         maxRequestSize = 1024 * 1024 * 50)
public class DeposeArticleServlet extends HttpServlet {

    @EJB
    private ArticleFacadeLocal articleFacade;

    @EJB
    private CategorieFacadeLocal categorieFacade;

        private final String UPLOAD_DIRECTORY = "C:\\Users\\Lenovo\\Documents\\NetBeansProjects\\VenteAuxEncheresApp\\VenteAuxEncheresApp-war\\web\\images\\";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            InputStream inputStream = null; // input stream of the upload file
            HttpSession session = request.getSession();
            Utilisateur user = (Utilisateur) session.getAttribute("user");

           String action = request.getParameter("action");
           
           if(action == null){
              request.setAttribute("allCategories", categorieFacade.findAll());
              request.getRequestDispatcher("deposeArticle.jsp").forward(request, response);
               
           }else{
                 try {
                   
                        int validForm = 1;
                        String nomArticle = request.getParameter("articleNom");
                        if (nomArticle==null || nomArticle.equals("")){
                            System.out.println(" --------- nom   -----------");
                            validForm = 0;
                        }

                        String descArticle = request.getParameter("desc");
                        if (descArticle==null){
                            System.out.println(" --------- desc   -----------");
                            validForm = 0;
                        }
                        
                        
                        String prixDepartStr = request.getParameter("prix");
                        double prixDepart = 0;
                        if(prixDepartStr!=null && !prixDepartStr.equals("")){
                            prixDepart=Double.parseDouble(prixDepartStr);    
                        } else {
                            System.out.println(" --------- prix   -----------");
                            validForm = 0;
                        }
                     
                     
                        Date dateDepot = new Date();
                     
                    
                        String dateFinStrTmp = request.getParameter("dateFin");
                        String dateFinStr = null;
                        if(dateFinStrTmp!=null) {
                            System.out.println(" --------- date   -----------");
                            dateFinStr = dateFinStrTmp.replace("T", " ");
                        }
                        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                        Date dateFin = new Date();
                        if (dateFinStr!=null && !dateFinStr.equals("")) try {
                            dateFin = formatter.parse(dateFinStr);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        } else {
                            System.out.println(" --------- date 0   -----------");
                            validForm = 0;
                        }
                        Calendar c = Calendar.getInstance();
                        c.setTime(dateDepot);
                        c.add(Calendar.DATE, 1);
                        String todayTmp = formatter.format(c.getTime());
                        String today = todayTmp.replace(" ", "T");
                        request.setAttribute("today", today);
                        
                         String cat = request.getParameter("category");
                         Categorie categorie = categorieFacade.findByNom(cat);
                         if(categorie == null || categorie.getNomCat().length()==0){
                             System.out.println(" --------- cat   ----------- "+cat);
                             validForm=0;
                         }
                        
                         //********************
                        Part part = request.getPart("file");
                        String fileExt = ".jpg";
                        String imgName = nomArticle + fileExt;//extractFileName(part);
                 
                        // obtains input stream of the upload file
                        inputStream = part.getInputStream();

                        byte[] buffer = new byte[inputStream.available()];
                        inputStream.read(buffer);

                        String imgPath = UPLOAD_DIRECTORY + nomArticle + fileExt;
                        File targetFile = new File(imgPath);
                        OutputStream outStream = new FileOutputStream(targetFile);
                        outStream.write(buffer);
                          //********************
                        
                        if(imgName.length() ==0 || imgPath.length() == 0){
                           validForm = 0; 
                        }
                        
                         if (validForm!=0){
                            Article article = new Article(nomArticle, descArticle, new Date(), dateFin, user, categorie, prixDepart, imgName, imgPath,"Encheres");
                            article.setPrixVendu(0.);
                            if ("Create".equalsIgnoreCase(action)) {
                                articleFacade.create(article);
                            } else if ("Cancle".equalsIgnoreCase(action)) {
                                response.sendRedirect(request.getContextPath() + "/ListeArticles.jsp");
                            }
                             System.out.println(" --------- 11   -----------");
                            request.getRequestDispatcher("MyArticlesServlet").forward(request, response);
                          }else{
                             System.out.println(" --------- 14   -----------");
                             request.setAttribute("Error", "Please recheck you entries!");
                             request.setAttribute("allCategories", categorieFacade.findAll());
                             request.getRequestDispatcher("deposeArticle.jsp").forward(request, response);
                         }
                         
                        } catch (Exception e) {
                            Logger.getLogger(DeposeArticleServlet.class.getName()).log(Level.SEVERE, null, e);
                        }
                        
                    
           }
      
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
