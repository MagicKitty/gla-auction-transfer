/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Commande;
import entities.Utilisateur;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.CommandeFacadeLocal;

/**
 *
 * @author Lenovo
 */
public class OdersListServlet extends HttpServlet {

    @EJB
    private CommandeFacadeLocal commandeFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
         HttpSession session = request.getSession(true);
         Utilisateur user = (Utilisateur) session.getAttribute("user");
        
         List<Commande> commandesWait = commandeFacade.getCmdWaitingByUser(user.getIdUser());
         
         request.setAttribute("commandes", commandesWait);  
         
         List<Commande> commandesValid = commandeFacade.getCmdValidatedByUser(user.getIdUser());
         
         request.setAttribute("commandesValid", commandesValid);
         
         List<Commande> commandesCance = commandeFacade.getCmdCanceledByUser(user.getIdUser());
         request.setAttribute("commandesCance", commandesCance);
         
         String indexCancel = request.getParameter("cancelID");
         
         String indexFacturation = request.getParameter("facturationID");
         
         String indexDelite = request.getParameter("deleteID");
         
         
        if(request.getParameter("commandeID") != null){
             Commande cmd = commandeFacade.recupererCMD(Long.parseLong(request.getParameter("commandeID")));
             request.setAttribute("cmd", cmd);
             request.setAttribute("type", 1); 
             request.getRequestDispatcher("OrdersList.jsp").forward(request, response);
        }else{
                request.setAttribute("type", 0);
         
                if(indexCancel != null){
                    commandeFacade.cancelCMD(commandesWait.get(Integer.parseInt(indexCancel)));
                    commandesWait = commandeFacade.getCmdWaitingByUser(user.getIdUser());
                    request.setAttribute("commandes", commandesWait);  
                    indexCancel=null;
                    request.getRequestDispatcher("OrdersList.jsp").forward(request, response);
                 }else{
                    if(indexFacturation != null){
                        request.setAttribute("commandeID", commandesValid.get(Integer.parseInt(indexFacturation)).getIdCmd());

                        request.getRequestDispatcher("./FacturationReqServlet").forward(request, response);
                        indexFacturation = null;
                    }else{
                       if(indexDelite != null){
                           commandesCance.get(Integer.parseInt(indexDelite)).setEtatDmd("Delited");
                           commandeFacade.edit(commandesCance.get(Integer.parseInt(indexDelite)));
                           commandesCance = commandeFacade.getCmdCanceledByUser(user.getIdUser());
                           request.setAttribute("commandesCance", commandesCance);
                           indexDelite= null;
                           request.getRequestDispatcher("OrdersList.jsp").forward(request, response);
                       }else{
                           request.getRequestDispatcher("OrdersList.jsp").forward(request, response); 
                       }
                    }
                }
    }
             
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
