/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Commande;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CommandeFacadeLocal;

/**
 *
 * @author Lenovo
 */
public class TraiterCMD extends HttpServlet {

    @EJB
    private CommandeFacadeLocal commandeFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        List<Commande> commandes = commandeFacade.getCmdTOValidate();
       
        if(request.getParameter("commandeID") != null){
             Commande cmd = commandeFacade.find(Long.parseLong(request.getParameter("commandeID")));
             
            if(request.getParameter("msg") == null){
                
                if(request.getParameter("action") == null){
                   request.setAttribute("cmd", cmd);
                   request.setAttribute("type", 1); 
                }else{
                    cmd.setEtatDmd("Validated"); 
                    cmd.setDateValidationAnnulation(new Date());
                    commandeFacade.edit(cmd);
                    commandes = commandeFacade.getCmdTOValidate();
                    request.setAttribute("type", 0);
                }
                
            }else{
                if("1".equalsIgnoreCase(request.getParameter("msg"))){
                    cmd.setEtatDmd("White not supported. The order is canceled.");                   
                   
                }else if("2".equalsIgnoreCase(request.getParameter("msg"))){
                    cmd.setEtatDmd("Size too big. The order is canceled.");
                }else if("3".equalsIgnoreCase(request.getParameter("msg"))){
                    cmd.setEtatDmd("One of the categories not supported. The order is canceled.");
                }else{
                    cmd.setEtatDmd("Breach of contract clauses. The order is canceled.");
                }
                 cmd.setDateValidationAnnulation(new Date());
                 commandeFacade.edit(cmd);
                 commandes = commandeFacade.getCmdTOValidate();
                 request.setAttribute("type", 0);
            }          
        }else{
             request.setAttribute("type", 0);
        }
        request.setAttribute("commandes", commandes);
        request.getRequestDispatcher("TraiterCMD.jsp").forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
