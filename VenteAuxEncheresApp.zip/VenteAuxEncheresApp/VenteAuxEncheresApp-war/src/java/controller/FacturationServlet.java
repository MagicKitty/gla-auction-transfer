/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Commande;
import entities.Facture;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CommandeFacadeLocal;
import model.FactureFacadeLocal;

/**
 *
 * @author Lenovo
 */
public class FacturationServlet extends HttpServlet {

    @EJB
    private FactureFacadeLocal factureFacade;

    @EJB
    private CommandeFacadeLocal commandeFacade;

  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //toute la facturation se fait ici
        
         List<Commande> commandesWait = commandeFacade.getCmdToFacturate();
         
         if(request.getParameter("commandeID") != null){
             Commande cmd = commandeFacade.recupererCMD(Long.parseLong(request.getParameter("commandeID")));
             request.setAttribute("cmd", cmd);
             request.setAttribute("type", 1); 
             request.setAttribute("typeBill", 0);
             request.setAttribute("commandes", commandesWait); 
             request.getRequestDispatcher("Facturation.jsp").forward(request, response);
         }else{
             if(request.getParameter("billID") != null){
                      
                      Commande cmd = commandeFacade.recupererCMD(Long.parseLong(request.getParameter("billID")));
                      Facture facture = new Facture();
                      facture.setIdFct(factureFacade.getMaxId()+1);
                      facture.setDateEdition(new Date());
                      facture.setIdCmd(cmd);
                      facture.setUtilisateur(cmd.getUtilisateur());
                      facture.setPrixTotal(cmd.getSomme());
                     
                      request.setAttribute("facture", facture);
                      request.setAttribute("typeBill", 1);
                      request.setAttribute("type",0); 
                      commandesWait = commandeFacade.getCmdToFacturate();
                      request.setAttribute("commandes", commandesWait); 
                      request.getRequestDispatcher("Facturation.jsp").forward(request, response);
                }else{
                 
                    if(request.getParameter("cmdBillID") != null){
                        Commande cmd = commandeFacade.recupererCMD(Long.parseLong(request.getParameter("cmdBillID")));
                        Facture facture = factureFacade.editerFacture(cmd);
                        request.setAttribute("facture", facture);
                        request.setAttribute("typeBill", 0);
                        request.setAttribute("type",0); 
                        commandesWait = commandeFacade.getCmdToFacturate();
                        request.setAttribute("commandes", commandesWait); 
                        request.getRequestDispatcher("Facturation.jsp").forward(request, response);
                    }else{
                        request.setAttribute("type", 0);    
                        request.setAttribute("typeBill", 0);
                        request.setAttribute("commandes", commandesWait); 
                        request.getRequestDispatcher("Facturation.jsp").forward(request, response); 
                    }
             }
             
           
         }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
