/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Article;
import entities.Commande;
import entities.Utilisateur;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.ConstraintViolationException;
import model.ArticleFacadeLocal;
import model.CommandeFacadeLocal;
import model.LigneCmdFacadeLocal;

/**
 *
 * @author Lenovo
 */
public class ArticlesWonServlet extends HttpServlet {
    @EJB
    private CommandeFacadeLocal commandeFacade;

    @EJB
    private ArticleFacadeLocal articleFacade;

    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        
            HttpSession session = request.getSession(true);
            Utilisateur user = (Utilisateur) session.getAttribute("user");
           
            List<Article> articles = articleFacade.getByIdGagnant(user.getIdUser());
            
            double sum = 0;
            for(int i=0 ; i<articles.size(); i++){
                sum=sum+articles.get(i).getPrixVendu();
            }
            if ("Order".equalsIgnoreCase(action)) {
                if(articles.size() > 0){
                    
                    String[] checkedIds = request.getParameterValues("checkedRows");
                     
                    Commande cmd = new Commande();
                    Date d = new Date();
                    cmd.setDateDmd(d);
                    cmd.setUtilisateur(user);
                    cmd.setEtatDmd("In the process of validation");
                    List<Article> ars = new ArrayList<Article>();
                    for(int i=0; i<checkedIds.length; i++){
                        ars.add(articles.get(Integer.parseInt(checkedIds[i])));
                    }
                    commandeFacade.saveOrders(cmd, ars);
                    getServletContext().getRequestDispatcher("/OdersListServlet").forward(request,response); 
                }else{
                    request.setAttribute("error", "You have no items to order! ");
                    request.getRequestDispatcher("ArticlesWon.jsp").forward(request, response);
                }
                             
            }else{
                
                String indexDelite = request.getParameter("deleteID");
                
                 if(indexDelite != null){
                     try{
                     articleFacade.annulerEnchereGagnee(articles.get(Integer.parseInt(indexDelite)), user);
                      } catch (ConstraintViolationException e) {
            System.out.println(" titem "+e);
                    e.getConstraintViolations().forEach(err->System.out.println(" --- --- "+err.toString()));
    }
                     System.out.println(" --------   10 --------");
                     articles = articleFacade.getByIdGagnant(user.getIdUser());
                     request.setAttribute("articlesWon", articles);
                      for(int i=0 ; i<articles.size(); i++){
                            sum=sum+articles.get(i).getPrixVendu();
                        }
                       request.setAttribute("sum", sum);
                     request.getRequestDispatcher("ArticlesWon.jsp").forward(request, response);
                 }else{
                    request.setAttribute("articlesWon", articles);
                    request.setAttribute("sum", sum);
                    request.getRequestDispatcher("ArticlesWon.jsp").forward(request, response);
                 }
                
            }
            
           
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
