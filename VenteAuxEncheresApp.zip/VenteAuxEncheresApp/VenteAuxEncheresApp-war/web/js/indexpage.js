$(document).ready(function(){
   
     $("#show-more").click(function () {
       $("#form-detail-order").toggle();
        
     });
     
});