/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Lenovo
 */
@Embeddable
public class ParticipePK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "ARTICLE")
    private long article;
    @Basic(optional = false)
    @NotNull
    @Column(name = "UTILISATEUR")
    private long utilisateur;

    public ParticipePK() {
    }

    public ParticipePK(long article, long utilisateur) {
        this.article = article;
        this.utilisateur = utilisateur;
    }

    public long getArticle() {
        return article;
    }

    public void setArticle(long article) {
        this.article = article;
    }

    public long getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(long utilisateur) {
        this.utilisateur = utilisateur;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) article;
        hash += (int) utilisateur;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ParticipePK)) {
            return false;
        }
        ParticipePK other = (ParticipePK) object;
        if (this.article != other.article) {
            return false;
        }
        if (this.utilisateur != other.utilisateur) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.ParticipePK[ article=" + article + ", utilisateur=" + utilisateur + " ]";
    }
    
}
