/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Lenovo
 */
@Entity
@Table(name = "COMMANDE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Commande.findAll", query = "SELECT c FROM Commande c")
    , @NamedQuery(name = "Commande.findTypedByUser", query = "SELECT c FROM Commande c WHERE c.utilisateur.idUser = :idUser AND c.etatDmd = :etatDmd ")
    , @NamedQuery(name = "Commande.findCancelByUser", query = "SELECT c FROM Commande c WHERE c.utilisateur.idUser = :idUser AND c.etatDmd LIKE :etatDmd ")
    , @NamedQuery(name = "Commande.findByUser", query = "SELECT c FROM Commande c WHERE c.utilisateur.idUser = :idUser")
    , @NamedQuery(name = "Commande.findByDateUser", query = "SELECT c FROM Commande c WHERE c.dateDmd = :dateDmd AND c.utilisateur.idUser = :idUser")
    , @NamedQuery(name = "Commande.findByIdCmd", query = "SELECT c FROM Commande c WHERE c.idCmd = :idCmd")
    , @NamedQuery(name = "Commande.findByDateDmd", query = "SELECT c FROM Commande c WHERE c.dateDmd = :dateDmd")
    , @NamedQuery(name = "Commande.findByEtatDmd", query = "SELECT c FROM Commande c WHERE c.etatDmd = :etatDmd")
    , @NamedQuery(name = "Commande.findByDateValidationAnnulation", query = "SELECT c FROM Commande c WHERE c.dateValidationAnnulation = :dateValidationAnnulation")
    , @NamedQuery(name = "Commande.findByDateDmdFacturation", query = "SELECT c FROM Commande c WHERE c.dateDmdFacturation = :dateDmdFacturation")})
public class Commande implements Serializable {

    private static final long serialVersionUID = 1L;
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_CMD")
    private Long idCmd;
    @Column(name = "DATE_DMD")
    @Temporal(TemporalType.DATE)
    private Date dateDmd;
    @Size(max = 50)
    @Column(name = "ETAT_DMD")
    private String etatDmd;
    @Column(name = "DATE_VALIDATION_ANNULATION")
    @Temporal(TemporalType.DATE)
    private Date dateValidationAnnulation;
    @Column(name = "DATE_DMD_FACTURATION")
    @Temporal(TemporalType.DATE)
    private Date dateDmdFacturation;
    @JoinColumn(name = "UTILISATEUR", referencedColumnName = "ID_USER")
    @ManyToOne
    private Utilisateur utilisateur;
    @OneToMany(mappedBy = "idCmd")
    private Collection<Facture> factureCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "commande")
    private Collection<LigneCmd> ligneCmdCollection;

    public Commande() {
    }

     @javax.persistence.Transient
     private double somme;

    public double getSomme() {
        return somme;
    }

    public void setSomme(double somme) {
        this.somme = somme;
    }
    
    public Commande(Long idCmd) {
        this.idCmd = idCmd;
    }

    public Long getIdCmd() {
        return idCmd;
    }

    public void setIdCmd(Long idCmd) {
        this.idCmd = idCmd;
    }

    public Date getDateDmd() {
        return dateDmd;
    }

    public void setDateDmd(Date dateDmd) {
        this.dateDmd = dateDmd;
    }

    public String getEtatDmd() {
        return etatDmd;
    }

    public void setEtatDmd(String etatDmd) {
        this.etatDmd = etatDmd;
    }

    public Date getDateValidationAnnulation() {
        return dateValidationAnnulation;
    }

    public void setDateValidationAnnulation(Date dateValidationAnnulation) {
        this.dateValidationAnnulation = dateValidationAnnulation;
    }

    public Date getDateDmdFacturation() {
        return dateDmdFacturation;
    }

    public void setDateDmdFacturation(Date dateDmdFacturation) {
        this.dateDmdFacturation = dateDmdFacturation;
    }

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    @XmlTransient
    public Collection<Facture> getFactureCollection() {
        return factureCollection;
    }

    public void setFactureCollection(Collection<Facture> factureCollection) {
        this.factureCollection = factureCollection;
    }

    @XmlTransient
    public Collection<LigneCmd> getLigneCmdCollection() {
        return ligneCmdCollection;
    }

    public void setLigneCmdCollection(Collection<LigneCmd> ligneCmdCollection) {
        this.ligneCmdCollection = ligneCmdCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCmd != null ? idCmd.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Commande)) {
            return false;
        }
        Commande other = (Commande) object;
        if ((this.idCmd == null && other.idCmd != null) || (this.idCmd != null && !this.idCmd.equals(other.idCmd))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Commande[ idCmd=" + idCmd + " ]";
    }
    
}
