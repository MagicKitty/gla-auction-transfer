/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Lenovo
 */
@Embeddable
public class LigneCmdPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_CMD")
    private long idCmd;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ARTICLE")
    private long article;

    public LigneCmdPK() {
    }

    public LigneCmdPK(long idCmd, long article) {
        this.idCmd = idCmd;
        this.article = article;
    }

    public long getIdCmd() {
        return idCmd;
    }

    public void setIdCmd(long idCmd) {
        this.idCmd = idCmd;
    }

    public long getArticle() {
        return article;
    }

    public void setArticle(long article) {
        this.article = article;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idCmd;
        hash += (int) article;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LigneCmdPK)) {
            return false;
        }
        LigneCmdPK other = (LigneCmdPK) object;
        if (this.idCmd != other.idCmd) {
            return false;
        }
        if (this.article != other.article) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.LigneCmdPK[ idCmd=" + idCmd + ", article=" + article + " ]";
    }
    
}
