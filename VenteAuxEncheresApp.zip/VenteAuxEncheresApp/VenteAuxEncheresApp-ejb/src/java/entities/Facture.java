/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lenovo
 */
@Entity
@Table(name = "FACTURE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Facture.findAll", query = "SELECT f FROM Facture f")
    , @NamedQuery(name = "Facture.findMaxId", query = "SELECT MAX(f.idFct) FROM Facture f ")
    , @NamedQuery(name = "Facture.findByIdUser", query = "SELECT f FROM Facture f WHERE f.utilisateur.idUser = :idUser")
    , @NamedQuery(name = "Facture.findByIdFct", query = "SELECT f FROM Facture f WHERE f.idFct = :idFct")
    , @NamedQuery(name = "Facture.findByDateEdition", query = "SELECT f FROM Facture f WHERE f.dateEdition = :dateEdition")
    , @NamedQuery(name = "Facture.findByPrixTotal", query = "SELECT f FROM Facture f WHERE f.prixTotal = :prixTotal")})
public class Facture implements Serializable {

    private static final long serialVersionUID = 1L;
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_FCT")
    private Long idFct;
    @Column(name = "DATE_EDITION")
    @Temporal(TemporalType.DATE)
    private Date dateEdition;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PRIX_TOTAL")
    private Double prixTotal;
    @JoinColumn(name = "ID_CMD", referencedColumnName = "ID_CMD")
    @ManyToOne
    private Commande idCmd;
    @JoinColumn(name = "UTILISATEUR", referencedColumnName = "ID_USER")
    @ManyToOne
    private Utilisateur utilisateur;

    public Facture() {
    }

    public Facture(Long idFct) {
        this.idFct = idFct;
    }

    public Long getIdFct() {
        return idFct;
    }

    public void setIdFct(Long idFct) {
        this.idFct = idFct;
    }

    public Date getDateEdition() {
        return dateEdition;
    }

    public void setDateEdition(Date dateEdition) {
        this.dateEdition = dateEdition;
    }

    public Double getPrixTotal() {
        return prixTotal;
    }

    public void setPrixTotal(Double prixTotal) {
        this.prixTotal = prixTotal;
    }

    public Commande getIdCmd() {
        return idCmd;
    }

    public void setIdCmd(Commande idCmd) {
        this.idCmd = idCmd;
    }

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFct != null ? idFct.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Facture)) {
            return false;
        }
        Facture other = (Facture) object;
        if ((this.idFct == null && other.idFct != null) || (this.idFct != null && !this.idFct.equals(other.idFct))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Facture[ idFct=" + idFct + " ]";
    }
    
}
