/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lenovo
 */
@Entity
@Table(name = "PARTICIPE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Participe.findAll", query = "SELECT p FROM Participe p")
    , @NamedQuery(name = "Participe.findByArticle", query = "SELECT p FROM Participe p WHERE p.participePK.article = :article")
    , @NamedQuery(name = "Participe.findByUtilisateur", query = "SELECT p FROM Participe p WHERE p.participePK.utilisateur = :utilisateur")
    , @NamedQuery(name = "Participe.findByPrixemis", query = "SELECT p FROM Participe p WHERE p.prixemis = :prixemis")
    , @NamedQuery(name = "Participe.findByDateparticipation", query = "SELECT p FROM Participe p WHERE p.dateparticipation = :dateparticipation")
    , @NamedQuery(name = "Participe.findByDateannulation", query = "SELECT p FROM Participe p WHERE p.dateannulation = :dateannulation")
    , @NamedQuery(name = "Participe.findMaxPrix", query = "SELECT MAX(p.prixemis) FROM Participe p WHERE p.participePK.article = :article")
    , @NamedQuery(name = "Participe.findGagnant", query = "SELECT p FROM Participe p WHERE p.participePK.article = :article AND (p.dateannulation = NULL)  AND p.prixemis in(SELECT MAX(p.prixemis) FROM Participe p WHERE p.participePK.article = :article)")})
public class Participe implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ParticipePK participePK;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PRIXEMIS")
    private Double prixemis;
    @Column(name = "DATEPARTICIPATION")
    @Temporal(TemporalType.DATE)
    private Date dateparticipation;
    @Column(name = "DATEANNULATION")
    @Temporal(TemporalType.DATE)
    private Date dateannulation;
    @JoinColumn(name = "ARTICLE", referencedColumnName = "ID_ARTICLE", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Article article1;
    @JoinColumn(name = "UTILISATEUR", referencedColumnName = "ID_USER", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Utilisateur utilisateur1;

    public Participe() {
    }

    public Participe(ParticipePK participePK) {
        this.participePK = participePK;
    }

    public Participe(long article, long utilisateur) {
        this.participePK = new ParticipePK(article, utilisateur);
    }

    public ParticipePK getParticipePK() {
        return participePK;
    }

    public void setParticipePK(ParticipePK participePK) {
        this.participePK = participePK;
    }

    public Double getPrixemis() {
        return prixemis;
    }

    public void setPrixemis(Double prixemis) {
        this.prixemis = prixemis;
    }

    public Date getDateparticipation() {
        return dateparticipation;
    }

    public void setDateparticipation(Date dateparticipation) {
        this.dateparticipation = dateparticipation;
    }

    public Date getDateannulation() {
        return dateannulation;
    }

    public void setDateannulation(Date dateannulation) {
        this.dateannulation = dateannulation;
    }

    public Article getArticle1() {
        return article1;
    }

    public void setArticle1(Article article1) {
        this.article1 = article1;
    }

    public Utilisateur getUtilisateur1() {
        return utilisateur1;
    }

    public void setUtilisateur1(Utilisateur utilisateur1) {
        this.utilisateur1 = utilisateur1;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (participePK != null ? participePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Participe)) {
            return false;
        }
        Participe other = (Participe) object;
        if ((this.participePK == null && other.participePK != null) || (this.participePK != null && !this.participePK.equals(other.participePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Participe[ participePK=" + participePK + " ]";
    }
    
}
