/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Lenovo
 */
@Entity
@Table(name = "UTILISATEUR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Utilisateur.findAll", query = "SELECT u FROM Utilisateur u")
    , @NamedQuery(name = "Utilisateur.findByIdUser", query = "SELECT u FROM Utilisateur u WHERE u.idUser = :idUser")
    , @NamedQuery(name = "Utilisateur.findByNomUser", query = "SELECT u FROM Utilisateur u WHERE u.nomUser = :nomUser")
    , @NamedQuery(name = "Utilisateur.findByPrenomUser", query = "SELECT u FROM Utilisateur u WHERE u.prenomUser = :prenomUser")
    , @NamedQuery(name = "Utilisateur.findByEmail", query = "SELECT u FROM Utilisateur u WHERE u.email = :email")
    , @NamedQuery(name = "Utilisateur.findByPassword", query = "SELECT u FROM Utilisateur u WHERE u.password = :password")
    , @NamedQuery(name = "Utilisateur.findByTel", query = "SELECT u FROM Utilisateur u WHERE u.tel = :tel")
    , @NamedQuery(name = "Utilisateur.findByPays", query = "SELECT u FROM Utilisateur u WHERE u.pays = :pays")
    , @NamedQuery(name = "Utilisateur.findByVille", query = "SELECT u FROM Utilisateur u WHERE u.ville = :ville")
    , @NamedQuery(name = "Utilisateur.findByRue", query = "SELECT u FROM Utilisateur u WHERE u.rue = :rue")
    , @NamedQuery(name = "Utilisateur.findByCodePostal", query = "SELECT u FROM Utilisateur u WHERE u.codePostal = :codePostal")
    , @NamedQuery(name = "Utilisateur.findByNbrEncherAnnuli", query = "SELECT u FROM Utilisateur u WHERE u.nbrEncherAnnuli = :nbrEncherAnnuli")
    , @NamedQuery(name = "Utilisateur.findByNumCb", query = "SELECT u FROM Utilisateur u WHERE u.numCb = :numCb")})
public class Utilisateur implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_USER")
    private Long idUser;
    @Size(max = 50)
    @Column(name = "NOM_USER")
    private String nomUser;
    @Size(max = 50)
    @Column(name = "PRENOM_USER")
    private String prenomUser;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 50)
    @Column(name = "EMAIL")
    private String email;
    @Size(max = 50)
    @Column(name = "PASSWORD")
    private String password;
    @Size(max = 20)
    @Column(name = "TEL")
    private String tel;
    @Size(max = 20)
    @Column(name = "PAYS")
    private String pays;
    @Size(max = 20)
    @Column(name = "VILLE")
    private String ville;
    @Size(max = 50)
    @Column(name = "RUE")
    private String rue;
    @Column(name = "CODE_POSTAL")
    private Integer codePostal;
    @Column(name = "NBR_ENCHER_ANNULI")
    private Integer nbrEncherAnnuli;
    @Column(name = "NUM_CB")
    private BigInteger numCb;
    @OneToMany(mappedBy = "utilisateur")
    private Collection<Commande> commandeCollection;
    @OneToMany(mappedBy = "gagnant")
    private Collection<Article> articleCollection;
    @OneToMany(mappedBy = "createur")
    private Collection<Article> articleCollection1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "utilisateur1")
    private Collection<Participe> participeCollection;
    @OneToMany(mappedBy = "utilisateur")
    private Collection<Facture> factureCollection;

    public Utilisateur() {
    }

      public Utilisateur(String prenom, String nom, String email, String password, String telephone) {
         this.prenomUser = prenom;
         this.nomUser = nom;
         this.email = email;
         this.password = password;
         this.tel = telephone;
         this.nbrEncherAnnuli=0;
    }

   public Utilisateur(String prenom, String nom, String email, String password, String telephone, String pay, String ville ,String rue, int code) {
         this.prenomUser = prenom;
         this.nomUser = nom;
         this.email = email;
         this.password = password;
         this.tel = telephone;
         this.pays=pay;
         this.ville=ville;
         this.rue = rue;
         this.codePostal=code;
         this.nbrEncherAnnuli=0;
    }
    
    public Utilisateur(Long idUser) {
        this.idUser = idUser;
    }

    public Long getIdUser() {
        return idUser;
    }

    public void setIdUser(Long idUser) {
        this.idUser = idUser;
    }

    public String getNomUser() {
        return nomUser;
    }

    public void setNomUser(String nomUser) {
        this.nomUser = nomUser;
    }

    public String getPrenomUser() {
        return prenomUser;
    }

    public void setPrenomUser(String prenomUser) {
        this.prenomUser = prenomUser;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getRue() {
        return rue;
    }

    public void setRue(String rue) {
        this.rue = rue;
    }

    public Integer getCodePostal() {
        return codePostal;
    }

    public void setCodePostal(Integer codePostal) {
        this.codePostal = codePostal;
    }

    public Integer getNbrEncherAnnuli() {
        return nbrEncherAnnuli;
    }

    public void setNbrEncherAnnuli(Integer nbrEncherAnnuli) {
        this.nbrEncherAnnuli = nbrEncherAnnuli;
    }

    public BigInteger getNumCb() {
        return numCb;
    }

    public void setNumCb(BigInteger numCb) {
        this.numCb = numCb;
    }

    @XmlTransient
    public Collection<Commande> getCommandeCollection() {
        return commandeCollection;
    }

    public void setCommandeCollection(Collection<Commande> commandeCollection) {
        this.commandeCollection = commandeCollection;
    }

    @XmlTransient
    public Collection<Article> getArticleCollection() {
        return articleCollection;
    }

    public void setArticleCollection(Collection<Article> articleCollection) {
        this.articleCollection = articleCollection;
    }

    @XmlTransient
    public Collection<Article> getArticleCollection1() {
        return articleCollection1;
    }

    public void setArticleCollection1(Collection<Article> articleCollection1) {
        this.articleCollection1 = articleCollection1;
    }

    @XmlTransient
    public Collection<Participe> getParticipeCollection() {
        return participeCollection;
    }

    public void setParticipeCollection(Collection<Participe> participeCollection) {
        this.participeCollection = participeCollection;
    }

    @XmlTransient
    public Collection<Facture> getFactureCollection() {
        return factureCollection;
    }

    public void setFactureCollection(Collection<Facture> factureCollection) {
        this.factureCollection = factureCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idUser != null ? idUser.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Utilisateur)) {
            return false;
        }
        Utilisateur other = (Utilisateur) object;
        if ((this.idUser == null && other.idUser != null) || (this.idUser != null && !this.idUser.equals(other.idUser))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Utilisateur[ idUser=" + idUser + " ]";
    }
    
}
