/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lenovo
 */
@Entity
@Table(name = "LIGNE_CMD")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "LigneCmd.findAll", query = "SELECT l FROM LigneCmd l")
    , @NamedQuery(name = "LigneCmd.findByIdCmd", query = "SELECT l FROM LigneCmd l WHERE l.ligneCmdPK.idCmd = :idCmd")
    , @NamedQuery(name = "LigneCmd.findByArticle", query = "SELECT l FROM LigneCmd l WHERE l.ligneCmdPK.article = :article")
    , @NamedQuery(name = "LigneCmd.sommeCMD", query = "SELECT SUM(l.article1.prixVendu) FROM LigneCmd l WHERE l.ligneCmdPK.idCmd = :idCmd")})
public class LigneCmd implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected LigneCmdPK ligneCmdPK;
    
    @JoinColumn(name = "ARTICLE", referencedColumnName = "ID_ARTICLE", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Article article1;
    @JoinColumn(name = "ID_CMD", referencedColumnName = "ID_CMD", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Commande commande;

    public LigneCmd() {
    }

    public LigneCmd(LigneCmdPK ligneCmdPK) {
        this.ligneCmdPK = ligneCmdPK;
    }

    public LigneCmd(long idCmd, long article) {
        this.ligneCmdPK = new LigneCmdPK(idCmd, article);
    }

    public LigneCmdPK getLigneCmdPK() {
        return ligneCmdPK;
    }

    public void setLigneCmdPK(LigneCmdPK ligneCmdPK) {
        this.ligneCmdPK = ligneCmdPK;
    }

    public Article getArticle1() {
        return article1;
    }

    public void setArticle1(Article article1) {
        this.article1 = article1;
    }

    public Commande getCommande() {
        return commande;
    }

    public void setCommande(Commande commande) {
        this.commande = commande;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ligneCmdPK != null ? ligneCmdPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LigneCmd)) {
            return false;
        }
        LigneCmd other = (LigneCmd) object;
        if ((this.ligneCmdPK == null && other.ligneCmdPK != null) || (this.ligneCmdPK != null && !this.ligneCmdPK.equals(other.ligneCmdPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.LigneCmd[ ligneCmdPK=" + ligneCmdPK + " ]";
    }
    
}
