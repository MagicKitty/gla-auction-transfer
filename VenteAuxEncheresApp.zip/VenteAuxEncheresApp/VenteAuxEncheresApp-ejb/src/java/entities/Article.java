/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Lenovo
 */
@Entity
@Table(name = "ARTICLE")
@XmlRootElement
@NamedQueries({
       @NamedQuery(name = "Article.findAllSearch", query = ""
            + "SELECT a FROM Article a, Categorie c WHERE (( "
            + "lower(:searchName) IS NULL OR "
            + "lower(:searchName) LIKE '' OR "
            + "lower(a.nomArticle) LIKE lower(:searchName)) AND ("
            + "lower(c.nomCat) LIKE lower(:catName) OR "
            + "lower(c.nomCat) IS NULL OR "
            + "lower(:catName) LIKE '') AND "
            + "a.categorie.idCat = c.idCat)"),
    @NamedQuery(name = "Article.findNameSearch", query = ""
            + "SELECT a FROM Article a WHERE ("
            + "lower(:searchName) IS NULL OR "
            + "lower(:searchName) LIKE '' OR "
            + "lower(a.nomArticle) LIKE lower(:searchName))"),
     @NamedQuery(name = "Article.findByCreateur", query = "SELECT a FROM Article a WHERE a.createur.idUser = :createur")
    , @NamedQuery(name = "Article.findAll", query = "SELECT a FROM Article a")
    , @NamedQuery(name = "Article.findByIdGagnant", query = "SELECT a FROM Article a WHERE a.gagnant.idUser = :id AND a.etatArticle = 'Gangné' ")
    , @NamedQuery(name = "Article.findByIdCat", query = "SELECT a FROM Article a WHERE a.categorie.idCat = :idCat")
    , @NamedQuery(name = "Article.findByIdArticle", query = "SELECT a FROM Article a WHERE a.idArticle = :idArticle")
    , @NamedQuery(name = "Article.findByNomArticle", query = "SELECT a FROM Article a WHERE a.nomArticle = :nomArticle")
    , @NamedQuery(name = "Article.findByDescArticle", query = "SELECT a FROM Article a WHERE a.descArticle = :descArticle")
    , @NamedQuery(name = "Article.findByDateDepos", query = "SELECT a FROM Article a WHERE a.dateDepos = :dateDepos")
    , @NamedQuery(name = "Article.findByDateFin", query = "SELECT a FROM Article a WHERE a.dateFin = :dateFin")
    , @NamedQuery(name = "Article.findByPrixDepart", query = "SELECT a FROM Article a WHERE a.prixDepart = :prixDepart")
    , @NamedQuery(name = "Article.findByEtatArticle", query = "SELECT a FROM Article a WHERE a.etatArticle = :etatArticle")
    , @NamedQuery(name = "Article.findByPhotoUrl", query = "SELECT a FROM Article a WHERE a.photoUrl = :photoUrl")
    , @NamedQuery(name = "Article.findByPrixVendu", query = "SELECT a FROM Article a WHERE a.prixVendu = :prixVendu")})
public class Article implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_ARTICLE")
    private Long idArticle;
    @Size(max = 50)
    @Column(name = "NOM_ARTICLE")
    private String nomArticle;
    @Size(max = 255)
    @Column(name = "DESC_ARTICLE")
    private String descArticle;
    @Column(name = "DATE_DEPOS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDepos;
    @Column(name = "DATE_FIN")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFin;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "PRIX_DEPART")
    private Double prixDepart;
    @Size(max = 10)
    @Column(name = "ETAT_ARTICLE")
    private String etatArticle;
    @Size(max = 32672)
    @Column(name = "PHOTO_URL")
    private String photoUrl;
    @Size(max = 50)
    @Column(name = "PHOTO_NOM")
    private String photoNom;
    @Column(name = "PRIX_VENDU")
    private Double prixVendu;
    @JoinColumn(name = "CATEGORIE", referencedColumnName = "ID_CAT")
    @ManyToOne
    private Categorie categorie;
    @JoinColumn(name = "GAGNANT", referencedColumnName = "ID_USER")
    @ManyToOne
    private Utilisateur gagnant;
    @JoinColumn(name = "CREATEUR", referencedColumnName = "ID_USER")
    @ManyToOne
    private Utilisateur createur;
    @OneToMany(mappedBy = "article")
    private Collection<Promotion> promotionCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "article1")
    private Collection<Participe> participeCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "article1")
    private Collection<LigneCmd> ligneCmdCollection;

    
     @javax.persistence.Transient
    private HashMap<Article, Double> hmap;
    
    public HashMap<Article, Double> getHmap() {
        return hmap;
    }

 
     public Article(String articleNom, String desc, Date dateDepose, Date dateLimite, Categorie categorie, double prix, String fileName, String savePath) {
        this.nomArticle=articleNom;
        this.descArticle = desc;
        this.dateDepos = dateDepose;
        this.dateFin = dateLimite;
        this.categorie=categorie;
        this.prixDepart = prix;
        this.photoNom = fileName;
        this.photoUrl= savePath;
    }

      public Article(String articleNom, String desc, Date dateDepose, Date dateLimite, Utilisateur creatreur, Categorie categorie, double prix, String imgName, String imgPath, String etat) {
         this.nomArticle=articleNom;
        this.descArticle = desc;
        this.dateDepos = dateDepose;
        this.dateFin = dateLimite;
        this.createur= creatreur;
        this.categorie=categorie;
        this.prixDepart = prix;
        this.photoNom = imgName;
        this.photoUrl= imgPath;
        this.etatArticle = etat;
    }


    
    public void setHmap(HashMap<Article, Double> hmap) {
        this.hmap = hmap;
    }
    
    public Article() {
    }

    public Article(Long idArticle) {
        this.idArticle = idArticle;
    }

    public Long getIdArticle() {
        return idArticle;
    }

    public void setIdArticle(Long idArticle) {
        this.idArticle = idArticle;
    }
    
    public String getPhotoNom() {
        return photoNom;
    }

    public void setPhotoNom(String photoNom) {
        this.photoNom = photoNom;
    }
    public String getNomArticle() {
        return nomArticle;
    }

    public void setNomArticle(String nomArticle) {
        this.nomArticle = nomArticle;
    }

    public String getDescArticle() {
        return descArticle;
    }

    public void setDescArticle(String descArticle) {
        this.descArticle = descArticle;
    }

    public Date getDateDepos() {
        return dateDepos;
    }

    public void setDateDepos(Date dateDepos) {
        this.dateDepos = dateDepos;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public Double getPrixDepart() {
        return prixDepart;
    }

    public void setPrixDepart(Double prixDepart) {
        this.prixDepart = prixDepart;
    }

    public String getEtatArticle() {
        return etatArticle;
    }

    public void setEtatArticle(String etatArticle) {
        this.etatArticle = etatArticle;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public Double getPrixVendu() {
        return prixVendu;
    }

    public void setPrixVendu(Double prixVendu) {
        this.prixVendu = prixVendu;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }

    public Utilisateur getGagnant() {
        return gagnant;
    }

    public void setGagnant(Utilisateur gagnant) {
        this.gagnant = gagnant;
    }

    public Utilisateur getCreateur() {
        return createur;
    }

    public void setCreateur(Utilisateur createur) {
        this.createur = createur;
    }

    @XmlTransient
    public Collection<Promotion> getPromotionCollection() {
        return promotionCollection;
    }

    public void setPromotionCollection(Collection<Promotion> promotionCollection) {
        this.promotionCollection = promotionCollection;
    }

    @XmlTransient
    public Collection<Participe> getParticipeCollection() {
        return participeCollection;
    }

    public void setParticipeCollection(Collection<Participe> participeCollection) {
        this.participeCollection = participeCollection;
    }

    @XmlTransient
    public Collection<LigneCmd> getLigneCmdCollection() {
        return ligneCmdCollection;
    }

    public void setLigneCmdCollection(Collection<LigneCmd> ligneCmdCollection) {
        this.ligneCmdCollection = ligneCmdCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idArticle != null ? idArticle.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Article)) {
            return false;
        }
        Article other = (Article) object;
        if ((this.idArticle == null && other.idArticle != null) || (this.idArticle != null && !this.idArticle.equals(other.idArticle))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Article[ idArticle=" + idArticle + " ]";
    }
    
}
