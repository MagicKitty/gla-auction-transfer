/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Participe;
import entities.ParticipePK;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Lenovo
 */
@Stateless
public class ParticipeFacade extends AbstractFacade<Participe> implements ParticipeFacadeLocal {

    @PersistenceContext(unitName = "VenteAuxEncheresApp-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ParticipeFacade() {
        super(Participe.class);
    }
     @Override
    public double getMaxPrix(Long id_article) {
        Object o = em.createNamedQuery("Participe.findMaxPrix").setParameter("article", id_article).getSingleResult();
        if(o == null) {
            return 0.;
        }
        return (double) o;
    }

    @Override
    public void merge(Participe participe) {
        em.merge(participe);
    }
      @Override
    public Participe getGagnantAuxEnchere(long id_article) {
        try {
            List<Participe> gagnantParticipanListt = em.createNamedQuery("Participe.findGagnant").setParameter("article", id_article).getResultList();

            if(gagnantParticipanListt.isEmpty()){
                return null;
            }else{
                Participe gagnantParticipant = gagnantParticipanListt.get(0);
            return (Participe) gagnantParticipant;
            }
        } catch (Exception e) {
            System.out.println("***************************************ejb err " + e);
            return null;
        }
    }

    @Override
    public Participe getParticipation(long idArticle, long idUser) {
        ParticipePK pk = new ParticipePK(idArticle, idUser);
        return this.find(pk);
    }
    
    
}
