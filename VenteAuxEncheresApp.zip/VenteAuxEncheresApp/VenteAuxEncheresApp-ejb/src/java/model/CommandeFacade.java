/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Article;
import entities.Commande;
import entities.LigneCmd;
import entities.LigneCmdPK;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Lenovo
 */
@Stateless
public class CommandeFacade extends AbstractFacade<Commande> implements CommandeFacadeLocal {

    @EJB
    private LigneCmdFacadeLocal ligneCmdFacade1;

    @EJB
    private ArticleFacadeLocal articleFacade;

    @EJB
    private LigneCmdFacadeLocal ligneCmdFacade;

    
    @PersistenceContext(unitName = "VenteAuxEncheresApp-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CommandeFacade() {
        super(Commande.class);
    }
    
   
    
    
    @Override
    public List<Commande> getCmdValidatedByUser( Long idUser) {
        List<Commande> cs = em.createNamedQuery("Commande.findTypedByUser").setParameter("idUser", idUser).setParameter("etatDmd", "Validated").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }
        return cs;
    }
    
    @Override
    public List<Commande> getCmdCanceledByUser( Long idUser) {
        List<Commande> cs = em.createNamedQuery("Commande.findCancelByUser").setParameter("idUser", idUser).setParameter("etatDmd", "%canceled.").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }
        return cs;
    }
    
     @Override
    public List<Commande> getCmdWaitingByUser( Long idUser) {
        List<Commande> cs = em.createNamedQuery("Commande.findTypedByUser").setParameter("idUser", idUser).setParameter("etatDmd", "In the process of validation").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }
        return cs;
    }
    
    
    @Override
    public String saveOrders(Commande cmd, List<Article> articles) {
        try{
            em.persist(cmd);
            em.flush();
            LigneCmd ligne;
            List<LigneCmd> l = new ArrayList<LigneCmd>();
            for(int i=0 ; i<articles.size(); i++){
                LigneCmdPK pk =  new LigneCmdPK(cmd.getIdCmd(),articles.get(i).getIdArticle());
                ligne = new LigneCmd(pk);
                ligneCmdFacade.create(ligne);
                l.add(ligne);
                articles.get(i).setEtatArticle("Commandé");
                articleFacade.edit( articles.get(i));
            } 
            cmd.setLigneCmdCollection(l);
            this.edit(cmd);
            return "Succes";
        }catch(Exception e){
            return "Error ggggg "+e;
        }
        
    }

    @Override
    public List<Commande> getCmdTOValidate() {
       List<Commande> cs = em.createNamedQuery("Commande.findByEtatDmd").setParameter("etatDmd", "In the process of validation").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }
        return cs;
    }   

    @Override
    public List<Commande> getCmdEnvoyees() {
         List<Commande> cs = em.createNamedQuery("Commande.findByEtatDmd").setParameter("etatDmd", "Validated").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }
        return cs;
    }

    @Override
    public void cancelCMD(Commande cmd) {
         try{
            
            cmd.setEtatDmd("The order is canceled by owner.");
            cmd.setDateValidationAnnulation(new Date());
            
           this.edit(cmd);
            
            List<LigneCmd> ls = new ArrayList(cmd.getLigneCmdCollection()); 
            for(int i=0 ; i<ls.size(); i++){
                articleFacade.find(ls.get(i).getLigneCmdPK().getArticle()).setEtatArticle("Gangné");
                articleFacade.edit( articleFacade.find(ls.get(i).getLigneCmdPK().getArticle()));
            } 
        }catch(Exception e){
             System.out.println("Error cancel");
        }
    }

    @Override
    public List<Commande> getCmdTerminees() {
         List<Commande> cs = em.createNamedQuery("Commande.findByEtatDmd").setParameter("etatDmd", "Received").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }
        return cs;
    
    }

    @Override
    public Commande recupererCMD(long id) {
        Commande cmd = this.find(id);
        cmd.setSomme(ligneCmdFacade.getSommeCMD( cmd.getIdCmd()));
        List<LigneCmd> ls = new ArrayList(cmd.getLigneCmdCollection()); 
        for(int i=0 ; i<ls.size(); i++){
               ls.get(i).setArticle1(articleFacade.find(ls.get(i).getLigneCmdPK().getArticle()));
           } 
        cmd.setLigneCmdCollection(ls);
        return cmd;
    }

    @Override
    public List<Commande> getCmdToFacturateUSer(long idUser) {
          List<Commande> cs = em.createNamedQuery("Commande.findTypedByUser").setParameter("idUser", idUser).setParameter("etatDmd", "Billing in progress").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }
        return cs;
    }

    @Override
    public List<Commande> getCmdToFacturate() {
         List<Commande> cs = em.createNamedQuery("Commande.findByEtatDmd").setParameter("etatDmd", "Billing in progress").getResultList();
        for(int i=0; i<cs.size(); i++){
            cs.get(i).setSomme(ligneCmdFacade.getSommeCMD( cs.get(i).getIdCmd()));
        }        
        return cs;
    }
    
    
    
    
    
}
