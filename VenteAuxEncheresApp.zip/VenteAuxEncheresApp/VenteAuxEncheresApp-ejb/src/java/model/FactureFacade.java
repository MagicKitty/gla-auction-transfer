/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Commande;
import entities.Facture;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Lenovo
 */
@Stateless
public class FactureFacade extends AbstractFacade<Facture> implements FactureFacadeLocal {

    @EJB
    private CommandeFacadeLocal commandeFacade;

    @PersistenceContext(unitName = "VenteAuxEncheresApp-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public FactureFacade() {
        super(Facture.class);
    }

    @Override
    public Facture editerFacture(Commande cmd) {
        
        Facture facture = new Facture();
        facture.setIdCmd(cmd);
        facture.setUtilisateur(cmd.getUtilisateur());
        facture.setDateEdition(new Date());
        facture.setPrixTotal( cmd.getSomme());
        
         em.persist(facture);
         em.flush();
        cmd.setEtatDmd("The order is paid");
        commandeFacade.edit(cmd);
        return facture;
    }

    @Override
    public long getMaxId() {
        try{
        return (long) em.createNamedQuery("Facture.findMaxId").getSingleResult();
        }catch(Exception e){
            System.out.println("-----------------"+e);
            return 0L;
        }
 
    }

    @Override
    public List<Facture> getFactureByUser(long idUser) { 
        List<Facture> fs = em.createNamedQuery("Facture.findByIdUser").setParameter("idUser", idUser).getResultList();
            return fs;
    }
    
    
    
}
