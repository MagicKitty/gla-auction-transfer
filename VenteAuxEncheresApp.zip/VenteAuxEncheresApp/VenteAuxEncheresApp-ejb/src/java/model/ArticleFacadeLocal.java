/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Article;
import entities.Categorie;
import entities.Utilisateur;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Lenovo
 */
@Local
public interface ArticleFacadeLocal {

    void create(Article article);

    void edit(Article article);

    void remove(Article article);

    Article find(Object id);

    List<Article> findAll();

    List<Article> findRange(int[] range);

    int count();

    Article findById(long id);
    
    List<Article> getByIdCat(Long idCat);

    List<Article> getByIdGagnant(long id);

    void annulerEnchereGagnee(Article art, Utilisateur user);
    
    
    List<Article> findMyArticleList(long idCreateur);
    
    List<Article> chercherArticleByNom(String nom);
    
    List<Article> chercherArticleByPrix(double prix);

    List<Article> chercherArticleByCategory(Categorie cat);
        
    List getAllWithSearch(String searchByName, String catName);
    
    List getAllWithSearch(String searchByName);
    
    List getAllArticles();
    
    void UpdateGangantDansArticle(Article article, Utilisateur gangant);
  
    
}
