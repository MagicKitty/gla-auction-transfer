/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Article;
import entities.Categorie;
import entities.Participe;
import entities.Utilisateur;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.validation.ConstraintViolationException;

/**
 *
 * @author Lenovo
 */
@Stateless
public class ArticleFacade extends AbstractFacade<Article> implements ArticleFacadeLocal {

    @EJB
    private UtilisateurFacadeLocal utilisateurFacade;

    @EJB
    private ParticipeFacadeLocal participeFacade;

    @PersistenceContext(unitName = "VenteAuxEncheresApp-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ArticleFacade() {
        super(Article.class);
    }
    
     @Override
    public List<Article> getByIdCat(Long idCat) {
        return  em.createNamedQuery("Article.findByIdCat").setParameter("idCat", idCat).getResultList();
    }

    @Override
    public List<Article> getByIdGagnant(long id) {
        return em.createNamedQuery("Article.findByIdGagnant").setParameter("id", id).getResultList();
    }

    @Override
    public void annulerEnchereGagnee(Article art , Utilisateur user) {
     
         System.out.println(" ---------   1  -------");
         Participe p =participeFacade.getParticipation(art.getIdArticle(), user.getIdUser());
         p.setDateannulation(new Date());
         p.setPrixemis(0.);
         participeFacade.merge(p);
         user.setNbrEncherAnnuli(user.getNbrEncherAnnuli()+1);
         utilisateurFacade.edit(user);
        Participe p2 = participeFacade.getGagnantAuxEnchere(art.getIdArticle());
                if(p2!=null){
                     art.setPrixVendu(p2.getPrixemis());
                     this.UpdateGangantDansArticle(art,p2.getUtilisateur1());
                   
                }else{
                    if(art.getDateFin().before(new Date()) ){
                        art.setEtatArticle("Canceled W");
                        this.edit(art);
                          }
                }
    }
    
     @Override
    public Article findById(long id) {
        System.out.println("id =" + id);
        try {

            Article article = (Article) em.createQuery("SELECT a FROM Article a WHERE a.idArticle = :idArticle").setParameter("idArticle", id).getSingleResult();

            return article;
        } catch (Exception e) {
            System.out.println("***************************************ejb err " + e);
            return null;
        }
    }

    @Override
    public List<Article> findMyArticleList(long idCreateur) {

        try {

            List<Article> articles = em.createNamedQuery("Article.findByCreateur").setParameter("createur", idCreateur).getResultList();

            return articles;
        } catch (Exception e) {
            System.out.println("***************************************ejb err " + e);
            return null;
        }
    }

    @Override
    public List<Article> chercherArticleByNom(String nom) {
        try {

            List<Article> articles = em.createNamedQuery("Article.findByNomArticle").setParameter("nomArticle", nom).getResultList();
            return articles;
        } catch (Exception e) {
            System.out.println("***************************************ejb err " + e);
            return null;
        }
    }

    @Override
    public List<Article> chercherArticleByPrix(double prix) {
        try {

            List<Article> articles = em.createNamedQuery("Article.findByPrixVendu").setParameter("prixVendu", prix).getResultList();
            return articles;
        } catch (Exception e) {
            System.out.println("***************************************ejb err " + e);
            return null;
        }
    }

    @Override
    public List<Article> chercherArticleByCategory(Categorie cat) {
         try {

            List<Article> articles =  em.createQuery("SELECT a FROM Article a WHERE a.categorie = :categorie").setParameter("categorie", cat).getResultList();

            return articles;
        } catch (Exception e) {
            System.out.println("***************************************ejb err " + e);
            return null;
        }
    }

    
     @Override
    public List getAllWithSearch(String searchByName, String catName){
        List l = em.createNamedQuery("Article.findAllSearch")
                .setParameter("searchName", "%"+searchByName+"%")
                .setParameter("catName", catName)
                .getResultList();
        if(!l.isEmpty())
            return l;
        return null;
    }
    
      
    @Override
    public List getAllWithSearch(String searchByName) {
        List l = em.createNamedQuery("Article.findNameSearch")
                .setParameter("searchName", "%" + searchByName + "%")
                .getResultList();
        if (!l.isEmpty()) {
            return l;
        }
        return null;
    }
    
    @Override
    public List getAllArticles(){
        List l = em.createNamedQuery("Article.findAll").getResultList();
        if(!l.isEmpty())
            return l;
        return null;
    }
    
     @Override
    public void UpdateGangantDansArticle(Article article, Utilisateur  gangant) {
         try {
                article.setGagnant(gangant);
                article.setEtatArticle("Gangné");
                this.edit(article);
                em.flush();
        } catch (Exception e) {
            System.out.println("***************************************ejb err " + e);
            
        }
    }

    public void persist(Object object) {
        em.persist(object);
    }
    
    
    
}
