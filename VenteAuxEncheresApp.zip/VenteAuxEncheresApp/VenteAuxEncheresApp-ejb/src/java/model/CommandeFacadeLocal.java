/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Article;
import entities.Commande;
import java.util.Date;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Lenovo
 */
@Local
public interface CommandeFacadeLocal {

    void create(Commande commande);

    void edit(Commande commande);

    void remove(Commande commande);

    Commande find(Object id);

    List<Commande> findAll();

    List<Commande> findRange(int[] range);

    int count();
    
    List<Commande> getCmdValidatedByUser( Long idUser);
    
    List<Commande> getCmdCanceledByUser( Long idUser);
    
    List<Commande> getCmdWaitingByUser( Long idUser);
    
    String saveOrders(Commande cmd, List<Article> lignes);

    List<Commande> getCmdTOValidate();

    List<Commande> getCmdEnvoyees();
    
    List<Commande> getCmdTerminees();

    void cancelCMD(Commande cmd);

    Commande recupererCMD(long id);

    List<Commande> getCmdToFacturateUSer(long idUser);

    List<Commande> getCmdToFacturate();
   
}
