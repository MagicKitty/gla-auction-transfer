/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Commande;
import entities.LigneCmd;
import entities.LigneCmdPK;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Lenovo
 */
@Stateless
public class LigneCmdFacade extends AbstractFacade<LigneCmd> implements LigneCmdFacadeLocal {

    @PersistenceContext(unitName = "VenteAuxEncheresApp-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public LigneCmdFacade() {
        super(LigneCmd.class);
    }

    @Override
    public double getSommeCMD(long idCMD) {
        return (double) em.createNamedQuery("LigneCmd.sommeCMD").setParameter("idCmd", idCMD).getSingleResult();
    }

    
}
