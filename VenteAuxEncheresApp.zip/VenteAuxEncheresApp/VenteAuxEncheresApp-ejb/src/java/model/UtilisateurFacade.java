/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Utilisateur;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Lenovo
 */
@Stateless
public class UtilisateurFacade extends AbstractFacade<Utilisateur> implements UtilisateurFacadeLocal {

    @PersistenceContext(unitName = "VenteAuxEncheresApp-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UtilisateurFacade() {
        super(Utilisateur.class);
    }
     @Override
    public Utilisateur getUser(String email, String password) {
        try {
            Utilisateur user =  (Utilisateur) em.createQuery( "SELECT u from Utilisateur u where u.email = :email and u.password =:password").setParameter("email", email).setParameter("password", password).getSingleResult();
                    return  user;
        } catch (Exception e) {
            System.out.println("***************************************ejb err "+e);
            return null;
        }
    }

   
}
