/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Categorie;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Lenovo
 */
@Stateless
public class CategorieFacade extends AbstractFacade<Categorie> implements CategorieFacadeLocal {

    @PersistenceContext(unitName = "VenteAuxEncheresApp-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CategorieFacade() {
        super(Categorie.class);
    }
    
      @Override
    public Categorie findByNom(String nom) {

        try {
            List<Categorie> categoryList = em.createNamedQuery("Categorie.findByNomCat").setParameter("nomCat", nom.trim()).getResultList();

            if (categoryList.isEmpty()) {
                return null;
            } else {
                Categorie category = categoryList.get(0);
                return (Categorie) category;
            }
        } catch (Exception e) {
            return null;
        }
    }
}
